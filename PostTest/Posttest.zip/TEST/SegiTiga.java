/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TEST;

/**
 *
 * @author swift 3
 */
public class SegiTiga {
    protected int sisi1;
    protected int tinggi;

    public SegiTiga(int sisi1, int tinggi) {
        this.sisi1 = sisi1;
        this.tinggi = tinggi;
    }
    
    public int hitungLuas(){
        return (this.sisi1*this.sisi1/2);
    }
    public int hitungKeliling(){
        return (this.sisi1*3);
    }
}
