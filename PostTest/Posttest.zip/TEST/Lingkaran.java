/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TEST;

/**
 *
 * @author swift 3
 */
public class Lingkaran {
    protected int r;

    public Lingkaran(int r) {
        this.r = r;
    }
    
    public double hitungLuas(){
        return Math.PI * r;
    }
    public double hitungKeliling(){
        return Math.PI + r;
    }
    
}
