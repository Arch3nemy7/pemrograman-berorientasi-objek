/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TEST;

/**
 *
 * @author swift 3
 */
public class JajarGenjang extends SegiEmpat{
    
    public JajarGenjang(int panjang, int lebar) {
        super(panjang, lebar);
    }

    @Override
    public int hitungKeliling() {
        return (super.sisi1*super.sisi1);
    }

    @Override
    public int hitungLuas() {
        return (super.sisi1 + super.sisi1) /2;
    }
    
    
    
}
