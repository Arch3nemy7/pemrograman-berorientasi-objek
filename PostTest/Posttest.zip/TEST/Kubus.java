/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TEST;

/**
 *
 * @author swift 3
 */
public class Kubus {
    SegiEmpat segiEmpat1;
    SegiEmpat segiEmpat2;
    SegiEmpat segiEmpat3;
    SegiEmpat segiEmpat4;
    SegiEmpat segiEmpat5;
    SegiEmpat segiEmpat6;
    protected int sisi;
    
    public Kubus(int sisi){
        this.sisi = sisi;
        this.segiEmpat1 = new SegiEmpat(sisi, sisi, sisi, sisi);
        this.segiEmpat2 = this.segiEmpat1;
        this.segiEmpat3 = this.segiEmpat1;
        this.segiEmpat4 = this.segiEmpat1;
        this.segiEmpat5 = this.segiEmpat1;
        this.segiEmpat6 = this.segiEmpat1;
    }
    
    public int hitungLuas(){
        return (this.segiEmpat1.hitungLuas() +
                this.segiEmpat2.hitungLuas() +
                this.segiEmpat3.hitungLuas() +
                this.segiEmpat4.hitungLuas() +
                this.segiEmpat5.hitungLuas()+
                this.segiEmpat6.hitungLuas());
    }
    
    public int hitungVolume(){
        return this.segiEmpat3.hitungLuas()*sisi;
    }
}
