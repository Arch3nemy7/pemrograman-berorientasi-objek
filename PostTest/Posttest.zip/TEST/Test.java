/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TEST;

/**
 *
 * @author swift 3
 */
public class Test {
    public static void main(String [] args){
        for(int i=0; i<500; i++){
            int sisiPersegi = i+1;
            SegiEmpat persegi = new SegiEmpat(sisiPersegi, 
                    sisiPersegi, sisiPersegi, sisiPersegi);
            System.out.println("Luas persegi "+(i+1)+" = "+persegi.hitungLuas());
            System.out.println("Keliling persegi "+(i+1)+" = "+persegi.hitungKeliling());
            
            Lingkaran lingkaran = new Lingkaran(sisiPersegi);
            System.out.println("Luas lingkaran "+(i+1)+" = "+lingkaran.hitungLuas());
            System.out.println("Keliling lingkaran "+(i+1)+" = "+lingkaran.hitungKeliling());
            
            SegiTiga segiTiga = new SegiTiga(sisiPersegi, sisiPersegi);
            System.out.println("Luas segiTiga "+(i+1)+" = "+segiTiga.hitungLuas());
            System.out.println("Keliling segiTiga "+(i+1)+" = "+segiTiga.hitungKeliling());
            
            JajarGenjang jajarGenjang = new JajarGenjang(sisiPersegi, sisiPersegi);
            System.out.println("Luas jajarGenjang "+(i+1)+" = "+jajarGenjang.hitungLuas());
            System.out.println("Keliling jajarGenjang "+(i+1)+" = "+jajarGenjang.hitungKeliling());
            
            Kubus kubus = new Kubus(sisiPersegi);
            System.out.println("Luas kubus "+(i+1)+" = "+kubus.hitungLuas());
            System.out.println("Volume kubus "+(i+1)+" = "+kubus.hitungVolume());
            
            Balok balok= new Balok(i);
            System.out.println("Luas balok "+(i+1)+" = "+balok.hitungLuas());
            System.out.println("Volume balok "+(i+1)+" = "+balok.hitungVolume());
            
            System.out.println("");
        }
    }
}
