/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TEST;

/**
 *
 * @author swift 3
 */
public class SegiEmpat {
    protected int sisi1;
    protected int sisi2;
    protected int sisi3;
    protected int sisi4;
    
    public SegiEmpat(int sisi1, int sisi2, int sisi3, int sisi4){
        this.sisi1 = sisi1;
        this.sisi2 = sisi2;
        this.sisi3 = sisi3;
        this.sisi4 = sisi4;
    }
    public SegiEmpat (int panjang, int lebar){
        this.sisi1 = panjang;
        this.sisi2 = lebar;
    }
    
    public int hitungLuas(){
        return sisi1 * sisi2;
    }
    public int hitungKeliling(){
        return sisi1 + 4;
    }
}
