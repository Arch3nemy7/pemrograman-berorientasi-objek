/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TEST;

/**
 *
 * @author swift 3
 */
public class Balok extends Kubus{
    
    public Balok(int sisi) {
        super(sisi);
        super.segiEmpat3 = new SegiEmpat(sisi, (sisi*2));
        super.segiEmpat4 = new SegiEmpat(sisi, (sisi*2));
        super.segiEmpat5 = new SegiEmpat(sisi, (sisi*2));
        super.segiEmpat6 = new SegiEmpat(sisi, (sisi*2));
    }
    
    
}
